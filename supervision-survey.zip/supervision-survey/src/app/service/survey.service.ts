import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SurveyService {

  constructor() { }

  //getSurveyQuestionsSection1():Observable<any> {
  getSurveyQuestionsSection1():any {
    console.log("Inside:getSurveyQuestionsSection1");
    return [
      {
        "question_id" : 1,
        "question_desc" : "I was treated with respect by supervision staff.",
        "is_required" : 1,
        "sort_order" : 1,
        "is_multiselect" : 0,
        "answer_id" : 1,
        "answer_desc" : "Select an Option",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 1,
        "question_desc" : "I was treated with respect by supervision staff.",
        "is_required" : 1,
        "sort_order" : 1,
        "is_multiselect" : 0,
        "answer_id" : 4,
        "answer_desc" : "Neutral",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 1,
        "question_desc" : "I was treated with respect by supervision staff.",
        "is_required" : 1,
        "sort_order" : 1,
        "is_multiselect" : 0,
        "answer_id" : 3,
        "answer_desc" : "Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 1,
        "question_desc" : "I was treated with respect by supervision staff.",
        "is_required" : 1,
        "sort_order" : 1,
        "is_multiselect" : 0,
        "answer_id" : 6,
        "answer_desc" : "Strongly Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 1,
        "question_desc" : "I was treated with respect by supervision staff.",
        "is_required" : 1,
        "sort_order" : 1,
        "is_multiselect" : 0,
        "answer_id" : 2,
        "answer_desc" : "Strongly Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 1,
        "question_desc" : "I was treated with respect by supervision staff.",
        "is_required" : 1,
        "sort_order" : 1,
        "is_multiselect" : 0,
        "answer_id" : 5,
        "answer_desc" : "Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 2,
        "question_desc" : "I feel that I was treated the same way as other individuals under supervision.",
        "is_required" : 1,
        "sort_order" : 2,
        "is_multiselect" : 0,
        "answer_id" : 5,
        "answer_desc" : "Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 2,
        "question_desc" : "I feel that I was treated the same way as other individuals under supervision.",
        "is_required" : 1,
        "sort_order" : 2,
        "is_multiselect" : 0,
        "answer_id" : 1,
        "answer_desc" : "Select an Option",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 2,
        "question_desc" : "I feel that I was treated the same way as other individuals under supervision.",
        "is_required" : 1,
        "sort_order" : 2,
        "is_multiselect" : 0,
        "answer_id" : 4,
        "answer_desc" : "Neutral",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 2,
        "question_desc" : "I feel that I was treated the same way as other individuals under supervision.",
        "is_required" : 1,
        "sort_order" : 2,
        "is_multiselect" : 0,
        "answer_id" : 3,
        "answer_desc" : "Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 2,
        "question_desc" : "I feel that I was treated the same way as other individuals under supervision.",
        "is_required" : 1,
        "sort_order" : 2,
        "is_multiselect" : 0,
        "answer_id" : 6,
        "answer_desc" : "Strongly Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 2,
        "question_desc" : "I feel that I was treated the same way as other individuals under supervision.",
        "is_required" : 1,
        "sort_order" : 2,
        "is_multiselect" : 0,
        "answer_id" : 2,
        "answer_desc" : "Strongly Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 3,
        "question_desc" : "The rules of supervision were clearly explained to me.",
        "is_required" : 1,
        "sort_order" : 3,
        "is_multiselect" : 0,
        "answer_id" : 2,
        "answer_desc" : "Strongly Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 3,
        "question_desc" : "The rules of supervision were clearly explained to me.",
        "is_required" : 1,
        "sort_order" : 3,
        "is_multiselect" : 0,
        "answer_id" : 5,
        "answer_desc" : "Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 3,
        "question_desc" : "The rules of supervision were clearly explained to me.",
        "is_required" : 1,
        "sort_order" : 3,
        "is_multiselect" : 0,
        "answer_id" : 1,
        "answer_desc" : "Select an Option",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 3,
        "question_desc" : "The rules of supervision were clearly explained to me.",
        "is_required" : 1,
        "sort_order" : 3,
        "is_multiselect" : 0,
        "answer_id" : 4,
        "answer_desc" : "Neutral",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 3,
        "question_desc" : "The rules of supervision were clearly explained to me.",
        "is_required" : 1,
        "sort_order" : 3,
        "is_multiselect" : 0,
        "answer_id" : 3,
        "answer_desc" : "Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 3,
        "question_desc" : "The rules of supervision were clearly explained to me.",
        "is_required" : 1,
        "sort_order" : 3,
        "is_multiselect" : 0,
        "answer_id" : 6,
        "answer_desc" : "Strongly Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 4,
        "question_desc" : "The Department's guidelines for giving a reward or sanction were fair.",
        "is_required" : 1,
        "sort_order" : 4,
        "is_multiselect" : 0,
        "answer_id" : 2,
        "answer_desc" : "Strongly Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 4,
        "question_desc" : "The Department's guidelines for giving a reward or sanction were fair.",
        "is_required" : 1,
        "sort_order" : 4,
        "is_multiselect" : 0,
        "answer_id" : 5,
        "answer_desc" : "Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 4,
        "question_desc" : "The Department's guidelines for giving a reward or sanction were fair.",
        "is_required" : 1,
        "sort_order" : 4,
        "is_multiselect" : 0,
        "answer_id" : 1,
        "answer_desc" : "Select an Option",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 4,
        "question_desc" : "The Department's guidelines for giving a reward or sanction were fair.",
        "is_required" : 1,
        "sort_order" : 4,
        "is_multiselect" : 0,
        "answer_id" : 4,
        "answer_desc" : "Neutral",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 4,
        "question_desc" : "The Department's guidelines for giving a reward or sanction were fair.",
        "is_required" : 1,
        "sort_order" : 4,
        "is_multiselect" : 0,
        "answer_id" : 3,
        "answer_desc" : "Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 4,
        "question_desc" : "The Department's guidelines for giving a reward or sanction were fair.",
        "is_required" : 1,
        "sort_order" : 4,
        "is_multiselect" : 0,
        "answer_id" : 6,
        "answer_desc" : "Strongly Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 5,
        "question_desc" : "DCS staff were supportive of my efforts to change.",
        "is_required" : 1,
        "sort_order" : 5,
        "is_multiselect" : 0,
        "answer_id" : 3,
        "answer_desc" : "Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 5,
        "question_desc" : "DCS staff were supportive of my efforts to change.",
        "is_required" : 1,
        "sort_order" : 5,
        "is_multiselect" : 0,
        "answer_id" : 6,
        "answer_desc" : "Strongly Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 5,
        "question_desc" : "DCS staff were supportive of my efforts to change.",
        "is_required" : 1,
        "sort_order" : 5,
        "is_multiselect" : 0,
        "answer_id" : 2,
        "answer_desc" : "Strongly Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 5,
        "question_desc" : "DCS staff were supportive of my efforts to change.",
        "is_required" : 1,
        "sort_order" : 5,
        "is_multiselect" : 0,
        "answer_id" : 5,
        "answer_desc" : "Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 5,
        "question_desc" : "DCS staff were supportive of my efforts to change.",
        "is_required" : 1,
        "sort_order" : 5,
        "is_multiselect" : 0,
        "answer_id" : 1,
        "answer_desc" : "Select an Option",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 5,
        "question_desc" : "DCS staff were supportive of my efforts to change.",
        "is_required" : 1,
        "sort_order" : 5,
        "is_multiselect" : 0,
        "answer_id" : 4,
        "answer_desc" : "Neutral",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 6,
        "question_desc" : "Meetings were held at times that were convenient for me.",
        "is_required" : 1,
        "sort_order" : 6,
        "is_multiselect" : 0,
        "answer_id" : 3,
        "answer_desc" : "Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 6,
        "question_desc" : "Meetings were held at times that were convenient for me.",
        "is_required" : 1,
        "sort_order" : 6,
        "is_multiselect" : 0,
        "answer_id" : 6,
        "answer_desc" : "Strongly Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 6,
        "question_desc" : "Meetings were held at times that were convenient for me.",
        "is_required" : 1,
        "sort_order" : 6,
        "is_multiselect" : 0,
        "answer_id" : 2,
        "answer_desc" : "Strongly Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 6,
        "question_desc" : "Meetings were held at times that were convenient for me.",
        "is_required" : 1,
        "sort_order" : 6,
        "is_multiselect" : 0,
        "answer_id" : 5,
        "answer_desc" : "Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 6,
        "question_desc" : "Meetings were held at times that were convenient for me.",
        "is_required" : 1,
        "sort_order" : 6,
        "is_multiselect" : 0,
        "answer_id" : 1,
        "answer_desc" : "Select an Option",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 6,
        "question_desc" : "Meetings were held at times that were convenient for me.",
        "is_required" : 1,
        "sort_order" : 6,
        "is_multiselect" : 0,
        "answer_id" : 4,
        "answer_desc" : "Neutral",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 7,
        "question_desc" : "My supervising officer was available when needed.",
        "is_required" : 1,
        "sort_order" : 7,
        "is_multiselect" : 0,
        "answer_id" : 1,
        "answer_desc" : "Select an Option",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 7,
        "question_desc" : "My supervising officer was available when needed.",
        "is_required" : 1,
        "sort_order" : 7,
        "is_multiselect" : 0,
        "answer_id" : 4,
        "answer_desc" : "Neutral",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 7,
        "question_desc" : "My supervising officer was available when needed.",
        "is_required" : 1,
        "sort_order" : 7,
        "is_multiselect" : 0,
        "answer_id" : 3,
        "answer_desc" : "Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 7,
        "question_desc" : "My supervising officer was available when needed.",
        "is_required" : 1,
        "sort_order" : 7,
        "is_multiselect" : 0,
        "answer_id" : 6,
        "answer_desc" : "Strongly Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 7,
        "question_desc" : "My supervising officer was available when needed.",
        "is_required" : 1,
        "sort_order" : 7,
        "is_multiselect" : 0,
        "answer_id" : 2,
        "answer_desc" : "Strongly Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 7,
        "question_desc" : "My supervising officer was available when needed.",
        "is_required" : 1,
        "sort_order" : 7,
        "is_multiselect" : 0,
        "answer_id" : 5,
        "answer_desc" : "Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 8,
        "question_desc" : "I was given the opportunity to provide input into my case plan.",
        "is_required" : 1,
        "sort_order" : 8,
        "is_multiselect" : 0,
        "answer_id" : 1,
        "answer_desc" : "Select an Option",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 8,
        "question_desc" : "I was given the opportunity to provide input into my case plan.",
        "is_required" : 1,
        "sort_order" : 8,
        "is_multiselect" : 0,
        "answer_id" : 4,
        "answer_desc" : "Neutral",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 8,
        "question_desc" : "I was given the opportunity to provide input into my case plan.",
        "is_required" : 1,
        "sort_order" : 8,
        "is_multiselect" : 0,
        "answer_id" : 3,
        "answer_desc" : "Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 8,
        "question_desc" : "I was given the opportunity to provide input into my case plan.",
        "is_required" : 1,
        "sort_order" : 8,
        "is_multiselect" : 0,
        "answer_id" : 6,
        "answer_desc" : "Strongly Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 8,
        "question_desc" : "I was given the opportunity to provide input into my case plan.",
        "is_required" : 1,
        "sort_order" : 8,
        "is_multiselect" : 0,
        "answer_id" : 2,
        "answer_desc" : "Strongly Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 8,
        "question_desc" : "I was given the opportunity to provide input into my case plan.",
        "is_required" : 1,
        "sort_order" : 8,
        "is_multiselect" : 0,
        "answer_id" : 5,
        "answer_desc" : "Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 9,
        "question_desc" : "I was given the opportunity to acquire the skills and knowledge I needed in order to succeed.",
        "is_required" : 1,
        "sort_order" : 9,
        "is_multiselect" : 0,
        "answer_id" : 5,
        "answer_desc" : "Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 9,
        "question_desc" : "I was given the opportunity to acquire the skills and knowledge I needed in order to succeed.",
        "is_required" : 1,
        "sort_order" : 9,
        "is_multiselect" : 0,
        "answer_id" : 1,
        "answer_desc" : "Select an Option",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 9,
        "question_desc" : "I was given the opportunity to acquire the skills and knowledge I needed in order to succeed.",
        "is_required" : 1,
        "sort_order" : 9,
        "is_multiselect" : 0,
        "answer_id" : 4,
        "answer_desc" : "Neutral",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 9,
        "question_desc" : "I was given the opportunity to acquire the skills and knowledge I needed in order to succeed.",
        "is_required" : 1,
        "sort_order" : 9,
        "is_multiselect" : 0,
        "answer_id" : 3,
        "answer_desc" : "Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 9,
        "question_desc" : "I was given the opportunity to acquire the skills and knowledge I needed in order to succeed.",
        "is_required" : 1,
        "sort_order" : 9,
        "is_multiselect" : 0,
        "answer_id" : 6,
        "answer_desc" : "Strongly Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 9,
        "question_desc" : "I was given the opportunity to acquire the skills and knowledge I needed in order to succeed.",
        "is_required" : 1,
        "sort_order" : 9,
        "is_multiselect" : 0,
        "answer_id" : 2,
        "answer_desc" : "Strongly Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 10,
        "question_desc" : "My efforts for doing well under supervision were recognized.",
        "is_required" : 1,
        "sort_order" : 10,
        "is_multiselect" : 0,
        "answer_id" : 2,
        "answer_desc" : "Strongly Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 10,
        "question_desc" : "My efforts for doing well under supervision were recognized.",
        "is_required" : 1,
        "sort_order" : 10,
        "is_multiselect" : 0,
        "answer_id" : 5,
        "answer_desc" : "Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 10,
        "question_desc" : "My efforts for doing well under supervision were recognized.",
        "is_required" : 1,
        "sort_order" : 10,
        "is_multiselect" : 0,
        "answer_id" : 1,
        "answer_desc" : "Select an Option",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 10,
        "question_desc" : "My efforts for doing well under supervision were recognized.",
        "is_required" : 1,
        "sort_order" : 10,
        "is_multiselect" : 0,
        "answer_id" : 4,
        "answer_desc" : "Neutral",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 10,
        "question_desc" : "My efforts for doing well under supervision were recognized.",
        "is_required" : 1,
        "sort_order" : 10,
        "is_multiselect" : 0,
        "answer_id" : 3,
        "answer_desc" : "Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 10,
        "question_desc" : "My efforts for doing well under supervision were recognized.",
        "is_required" : 1,
        "sort_order" : 10,
        "is_multiselect" : 0,
        "answer_id" : 6,
        "answer_desc" : "Strongly Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 11,
        "question_desc" : "DCS staff explained the steps to early realease from supervision.",
        "is_required" : 1,
        "sort_order" : 11,
        "is_multiselect" : 0,
        "answer_id" : 3,
        "answer_desc" : "Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 11,
        "question_desc" : "DCS staff explained the steps to early realease from supervision.",
        "is_required" : 1,
        "sort_order" : 11,
        "is_multiselect" : 0,
        "answer_id" : 6,
        "answer_desc" : "Strongly Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 11,
        "question_desc" : "DCS staff explained the steps to early realease from supervision.",
        "is_required" : 1,
        "sort_order" : 11,
        "is_multiselect" : 0,
        "answer_id" : 2,
        "answer_desc" : "Strongly Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 11,
        "question_desc" : "DCS staff explained the steps to early realease from supervision.",
        "is_required" : 1,
        "sort_order" : 11,
        "is_multiselect" : 0,
        "answer_id" : 5,
        "answer_desc" : "Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 11,
        "question_desc" : "DCS staff explained the steps to early realease from supervision.",
        "is_required" : 1,
        "sort_order" : 11,
        "is_multiselect" : 0,
        "answer_id" : 1,
        "answer_desc" : "Select an Option",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 11,
        "question_desc" : "DCS staff explained the steps to early realease from supervision.",
        "is_required" : 1,
        "sort_order" : 11,
        "is_multiselect" : 0,
        "answer_id" : 4,
        "answer_desc" : "Neutral",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 12,
        "question_desc" : "Overall, I am satisfied with my supervision experience.",
        "is_required" : 1,
        "sort_order" : 12,
        "is_multiselect" : 0,
        "answer_id" : 3,
        "answer_desc" : "Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 12,
        "question_desc" : "Overall, I am satisfied with my supervision experience.",
        "is_required" : 1,
        "sort_order" : 12,
        "is_multiselect" : 0,
        "answer_id" : 6,
        "answer_desc" : "Strongly Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 12,
        "question_desc" : "Overall, I am satisfied with my supervision experience.",
        "is_required" : 1,
        "sort_order" : 12,
        "is_multiselect" : 0,
        "answer_id" : 2,
        "answer_desc" : "Strongly Agree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 12,
        "question_desc" : "Overall, I am satisfied with my supervision experience.",
        "is_required" : 1,
        "sort_order" : 12,
        "is_multiselect" : 0,
        "answer_id" : 5,
        "answer_desc" : "Disagree",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 12,
        "question_desc" : "Overall, I am satisfied with my supervision experience.",
        "is_required" : 1,
        "sort_order" : 12,
        "is_multiselect" : 0,
        "answer_id" : 1,
        "answer_desc" : "Select an Option",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 12,
        "question_desc" : "Overall, I am satisfied with my supervision experience.",
        "is_required" : 1,
        "sort_order" : 12,
        "is_multiselect" : 0,
        "answer_id" : 4,
        "answer_desc" : "Neutral",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 13,
        "question_desc" : "Did any of the following DCS services help you successfully complete your supervision term? Select all that apply.",
        "is_required" : 0,
        "sort_order" : 13,
        "is_multiselect" : 0,
        "answer_id" : 9,
        "answer_desc" : "Call-In Reporting",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 13,
        "question_desc" : "Did any of the following DCS services help you successfully complete your supervision term? Select all that apply.",
        "is_required" : 0,
        "sort_order" : 13,
        "is_multiselect" : 0,
        "answer_id" : 12,
        "answer_desc" : "Community Coordinators",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 13,
        "question_desc" : "Did any of the following DCS services help you successfully complete your supervision term? Select all that apply.",
        "is_required" : 0,
        "sort_order" : 13,
        "is_multiselect" : 0,
        "answer_id" : 8,
        "answer_desc" : "Body Camera Recordings",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 13,
        "question_desc" : "Did any of the following DCS services help you successfully complete your supervision term? Select all that apply.",
        "is_required" : 0,
        "sort_order" : 13,
        "is_multiselect" : 0,
        "answer_id" : 11,
        "answer_desc" : "Counselling Services",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 13,
        "question_desc" : "Did any of the following DCS services help you successfully complete your supervision term? Select all that apply.",
        "is_required" : 0,
        "sort_order" : 13,
        "is_multiselect" : 0,
        "answer_id" : 7,
        "answer_desc" : "Video Calls",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 13,
        "question_desc" : "Did any of the following DCS services help you successfully complete your supervision term? Select all that apply.",
        "is_required" : 0,
        "sort_order" : 13,
        "is_multiselect" : 0,
        "answer_id" : 10,
        "answer_desc" : "Home Visits",
        "exit_survey_answer_id" : null,
        "answer_text" : null
      },
      {
        "question_id" : 14,
        "question_desc" : "Overall, Please feel free to provide any additional comments about your experience with the Department of Community Supervision.",
        "is_required" : 0,
        "sort_order" : 14,
        "is_multiselect" : 0,
        "answer_id" : null,
        "answer_desc" : null,
        "exit_survey_answer_id" : null,
        "answer_text" : null
      }
    ]
    
  }
}
