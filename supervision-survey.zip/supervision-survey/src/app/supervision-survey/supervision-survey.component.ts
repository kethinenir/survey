import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supervision-survey',
  templateUrl: './supervision-survey.component.html',
  styleUrls: ['./supervision-survey.component.css']
})
export class SupervisionSurveyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
