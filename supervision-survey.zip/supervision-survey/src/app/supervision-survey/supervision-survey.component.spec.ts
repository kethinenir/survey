import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SupervisionSurveyComponent } from './supervision-survey.component';

describe('SupervisionSurveyComponent', () => {
  let component: SupervisionSurveyComponent;
  let fixture: ComponentFixture<SupervisionSurveyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupervisionSurveyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupervisionSurveyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
