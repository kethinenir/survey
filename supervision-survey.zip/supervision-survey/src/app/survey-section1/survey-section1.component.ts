import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DynamicScriptLoaderServiceService } from '../service/dynamic-script-loader-service.service';
import { SurveyService } from '../service/survey.service';
import * as $ from 'jquery';
import  "jquery-validation";

@Component({
  selector: 'app-survey-section1',
  templateUrl: './survey-section1.component.html',
  styleUrls: ['./survey-section1.component.css']
})
export class SurveySection1Component implements OnInit {
  surveySection1Questionnaire:any=[]
  surveyForm: FormGroup=new FormGroup({});

  constructor(
    private dynamicScriptLoader: DynamicScriptLoaderServiceService,
    private surveyService: SurveyService,
    private formBuilder: FormBuilder,
    ) { }

  ngOnInit(): void {
    this.loadScripts();
    this.loadSurveySection();

    $(document).ready(function(){
      $('#continue').on('click', function() {
        $("#surveyForm").validate({ ignore: ":hidden:not(select)" });
      });
    });
    
  }

  private loadScripts() {
    // You can load multiple scripts by just providing the key as argument into load method of the service
    this.dynamicScriptLoader.load('jquery','jqueryValidation','chosenJquery','prism','init').then(data => {
      // Script Loaded Successfully
    }).catch(error => console.log(error));
  }

  private loadSurveySection(){
    let survey = this.surveyService.getSurveyQuestionsSection1();
    const ids = survey.map(o => o.question_id)
    const questions = survey.filter(({question_id}, index) => !ids.includes(question_id, index + 1)).map(s=>{
      const {question_id,question_desc,is_required,sort_order,is_multiselect,answer_id} = s;
      return {question_id,question_desc,is_required,sort_order,is_multiselect,answer_id}
    });

    
    const questionsGroup: any = {};
    for(let index in questions){
      let q = questions[index];
      questionsGroup[q.question_id] = ['',[Validators.required]];
      let options = survey.filter(s=>s.question_id===q.question_id).map(filteredObj => {
        const {answer_id,answer_desc,exit_survey_answer_id,answer_text} = filteredObj;
      return {answer_id,answer_desc,exit_survey_answer_id,answer_text}
      });
      options = options.sort((a, b) => {return (a['answer_id'] > b['answer_id']) ? 1 : (a['answer_id'] < b['answer_id']) ? -1 : 0;});
      q['answers'] = options;
      questions[index] = q;

    }
    this.surveyForm = this.formBuilder.group(questionsGroup);
    this.surveySection1Questionnaire = questions;
    console.log(this.surveySection1Questionnaire)
  }

  onFormSubmit(){
    console.log(this.surveyForm.valid)

  }
  

}
