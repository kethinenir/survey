import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SurveySection1Component } from './survey-section1.component';

describe('SurveySection1Component', () => {
  let component: SurveySection1Component;
  let fixture: ComponentFixture<SurveySection1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SurveySection1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SurveySection1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
